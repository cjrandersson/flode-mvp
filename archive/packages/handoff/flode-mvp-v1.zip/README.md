# flöde~ MVP

**MVP v1 target:** one functional Signal POD that becomes the template for Pods A–F.

## Current deliverable
- `max/flode_podA_MVP_v1.maxpat` — standalone Max patch shell with dual `dac~` + `plugout~` outputs
- drag-and-drop sample loading into `buffer~ podA`
- stereo `groove~` loop playback
- large waveform, Volume and Pan performance controls
- six generative modes: PURE, JUNG, WEIGHTED, WALK, MEMORY, CHAOS
- Random/Jung = generative depth; Jitter = micro-variation
- separate accent colors for signal/mix/generative controls
- presentation-mode UI designed as a single clean performance surface

## Run
1. Keep the `max/js/flode_gen.js` path beside the patch as committed.
2. Open `max/flode_podA_MVP_v1.maxpat` in Max 8/9.
3. Drop a WAV/AIFF onto the waveform.
4. Enable Max audio (`dac~`) for standalone testing.
5. Turn **GEN RUN** on to hear generative playback-speed motion.
6. Select a GEN MODE and adjust **RANDOM / JUNG** and **JITTER**.

## Max for Live
The patch already contains `plugout~` so the audio engine can be transferred into a Max Audio Effect shell. Saving a production `.amxd` should be done from Max for Live so Live-specific parameter metadata can be verified in Ableton.

## MVP philosophy
The main surface intentionally exposes only waveform, volume, pan and three generative decisions: mode, amount and jitter. Deeper slicing/transient/FX controls belong in the next expandable layer rather than the first screen.
